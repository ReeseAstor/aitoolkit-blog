# Social Launch Assets — Cold Email AI Swipe File

## Twitter/X Thread

1/ Cold outreach is not a numbers game.

It's a relevance game.

Here are 8 scenarios and 40 sequences that get replies.

2/ Scenario 1: Selling services to SaaS
Problem-first, results-first, resource, question, competitor mention.

Each sequence has a first email + 3 follow-ups.

3/ Scenario 2: Agency new business
Portfolio, capacity, niche, ROI, audit.

Stop pitching. Start diagnosing.

4/ Scenario 3: Recruitment / talent outreach
Opportunity, mission, referral, portfolio praise, passive candidate.

Respect their time. Get the response.

5/ The secret weapon:
First-line personalization prompts.

Drop the "hope you're well." Use AI to write a specific, natural opener.

6/ I packaged all 40 sequences + prompts + subject lines into one file.

$16. Instant download.

→ aitoolkit-blog.vercel.app/products

---

## Short-form video scripts

### Script A (30 sec)
0-3: “Cold emails get ignored because they sound mass-produced.”
3-8: “I made 40 sequences across 8 real scenarios.”
8-18: “SaaS sales, agency outreach, recruiting, link building, events, investors, re-engagement, referrals.”
18-25: “Each has subject lines, first email, 3 follow-ups, and an AI personalization prompt.”
25-30: “Link in bio. $16.”

### Script B (15 sec)
0-3: “40 cold email sequences.”
3-8: “First email + 3 follow-ups each.”
8-13: “AI personalization prompts included.”
13-15: “$16. Link in bio.”

---

## Email blast

Subject: 40 cold email sequences that book meetings

Preheader: First email + follow-ups + AI prompts — $16

Body:

Hey [first name],

Cold email is hard because most templates are too generic.

I built 40 complete sequences across 8 real scenarios:

- SaaS sales
- Agency new business
- Recruitment
- Link building
- Events
- Investor/partner outreach
- Re-engaging cold prospects
- Referral requests

Each sequence includes a first email, 3 follow-ups, subject lines, and a prompt to generate a personalized first line with AI.

Grab the Cold Email AI Swipe File: [link]

[Name]
