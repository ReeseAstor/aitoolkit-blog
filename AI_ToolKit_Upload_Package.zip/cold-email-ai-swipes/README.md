---
id: prod-005
status: ready
format: swipe file
title: Cold Email AI Swipe File: 40 Sequences That Book Meetings
slug: cold-email-ai-swipes
price_usd: 16
affiliate_tie: [Copy.ai, Writesonic]
article_tie: best-ai-tools-cold-email-outreach-2026
customer_pain: Cold emails get ignored. I need proven hooks.
search_hook: cold email templates AI
etsy_tags:
  - cold email template
  - sales email
  - B2B outreach
  - lead generation
  - email scripts
gumroad_categories: [Business]
---

# Cold Email AI Swipe File: 40 Sequences That Book Meetings

40 ready-to-personalize cold email sequences for founders, sales reps, agencies, and freelancers.

## What’s inside

- **8 outreach scenarios** × 5 sequences each = 40 sequences
- Each sequence = first email + 3 follow-ups
- AI personalization prompts for first lines
- Subject lines for every email
- Deliverability and reply-rate notes

## Scenarios covered

1. Selling services to SaaS companies
2. Agency new business
3. Recruitment / talent outreach
4. Link building / PR outreach
5. Event / webinar invitations
6. Investor / partnership outreach
7. Re-engaging cold prospects
8. Referral requests

## How to use

1. Pick your scenario.
2. Paste the sequence into your sales engagement tool.
3. Use the prompt to generate personalized first lines.
4. Follow the send timing in the notes.
5. Track replies and iterate.

## License

Personal use only. © 2026 AI ToolKit.
