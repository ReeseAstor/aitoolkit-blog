40 Cold Email Sequences That Book Meetings | AI Swipe File for B2B Outreach

Cold email that actually gets replies — not just opens.

Most cold emails get ignored because they sound like every other template. This swipe file gives you 40 proven sequences with personalized first-line prompts and 3-email follow-ups that have booked real meetings for founders, agencies, and sales teams.

## What's inside

- 40 cold email sequences across 8 industries (SaaS, agencies, consulting, recruiting, etc.)
- Personalized first-line prompt formulas that actually work
- 3-email follow-up sequences that don't feel spammy
- "Reply rate boosters" — subject lines, timing, and tone tweaks
- Recommended tool stack (Copy.ai + Instantly or Smartlead)

## Who this is for

- Founders and sales teams running outbound
- Agency owners booking discovery calls
- B2B consultants and coaches
- Anyone tired of low reply rates on cold outreach

## Format

Instant PDF + Markdown download. Personal use only.

—

*Affiliate disclosure: includes links to Copy.ai. We may earn a commission at no extra cost to you.*