Title (140 chars max):
Cold Email AI Swipe File | 40 Sequences That Book Meetings | B2B Outreach Templates

Tags (all 13):
cold email template, sales email, B2B outreach, lead generation, email scripts, outreach templates, follow up email, SDR templates, founder sales, agency outreach, recruitment email, link building outreach, digital download

Category:
Digital Downloads > Business & Productivity > Business Guides & Tutorials

Description:
40 cold email sequences that actually get replies.

This swipe file gives you complete sequences — first email + 3 follow-ups — across 8 real-world scenarios.

What’s included:
✅ 8 scenarios: SaaS sales, agency new business, recruitment, link building, events, investor/partner outreach, re-engagement, referrals
✅ 40 complete sequences
✅ First-line personalization prompts
✅ Subject lines for every email
✅ Send timing notes

Perfect for founders, SDRs, agencies, freelancers, and recruiters.

Format: Instant PDF + Markdown download
License: Personal use only

—

*Affiliate disclosure: includes links to Copy.ai and Writesonic. We may earn a commission if you sign up.*

Thank you for supporting AI ToolKit.
