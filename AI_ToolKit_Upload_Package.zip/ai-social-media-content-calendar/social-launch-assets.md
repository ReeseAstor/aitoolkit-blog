# Social Launch Assets — AI Social Media Content Machine

## Twitter/X Thread

1/ The hardest part of social media is not creation.

It's knowing what to post.

I built a 30-day calendar that solves that.

2/ 5 weekly themes:
- Monday: Educate
- Tuesday: Entertain
- Wednesday: Engage
- Thursday: Promote
- Friday: Prove

3/ Each day has:
- Post format
- Hook
- CTA
- AI prompt

No blank page. No guesswork.

4/ Plus:
- Hook bank
- Hashtag bank
- Repurposing map
- Visual briefs for Canva and AdCreative.ai

5/ One idea becomes 5 formats.

Carousel → Reel → Thread → LinkedIn article → email.

6/ Grab the AI Social Media Content Machine.

$15. Instant download.

→ aitoolkit-blog.vercel.app/products

---

## Short-form video scripts

### Script A (30 sec)
0-3: “You open Instagram. You have no idea what to post.”
3-8: “I made a 30-day AI content calendar.”
8-18: “Each day has a theme, format, hook, CTA, and AI prompt.”
18-25: “Educate, Entertain, Engage, Promote, Prove — every week.”
25-30: “Link in bio. $15.”

### Script B (15 sec)
0-3: “30 days of content ideas.”
3-8: “Done for you.”
8-13: “AI prompts included.”
13-15: “$15. Link in bio.”

---

## Email blast

Subject: A 30-day content calendar that posts itself

Preheader: Daily prompts, hooks, CTAs — $15

Body:

Hey [first name],

Staring at a blank screen every morning?

I built a 30-day social media content machine:

- Daily calendar with post type, hook, and CTA
- 30 AI prompts
- 5 weekly themes
- Hook and hashtag banks
- Repurposing map

Grab it for $15: [link]

[Name]
