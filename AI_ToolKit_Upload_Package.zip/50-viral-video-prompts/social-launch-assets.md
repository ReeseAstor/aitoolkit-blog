# Social Launch Assets — 50 Viral Short-Form Video Prompts

## Carousels

### Carousel 1: Hook Preview

**Slide 1:**
Headline: 50 viral hooks done for you
Sub: For Reels, TikTok, Shorts + AI voice/video | $12

**Slide 2:**
Problem: Staring at your phone trying to write line one.

**Slide 3:**
Solution: 10 hook frameworks × 5 prompts each = 50 scripts.

**Slide 4:**
Example frameworks:
- Mistake Hook
- Result Hook
- Hot Take Hook
- Question Hook
- Story Hook
- CTA Hook
+ 4 more

**Slide 5:**
CTA: Link in bio → aitoolkit-blog.vercel.app/products

---

## Twitter/X Thread

1/ I used to waste 30 minutes writing a 15-second hook.

Now I use a prompt framework.

Here are 50 of them, free in this thread:

2/ The Mistake Hook

“Stop making this mistake with [topic].”

Opens with pain → promises fix → keeps viewer watching.

3/ The Result Hook

“In [time], I [result]. Here’s how.”

Specific numbers beat vague promises. Every time.

4/ The Comparison Hook

“[Old way] used to work. Now it’s killing your [outcome].”

Creates instant clarity through contrast.

5/ The Hot Take Hook

“Unpopular opinion: [statement].”

Earns comments. Comments feed the algorithm.

6/ The CTA Hook

“If you want [outcome], do this now.”

Direct response. Best for lead gen and sales.

7/ I packaged 50 prompts across 10 frameworks into one pack.

Each prompt is fill-in-the-blank.

Just swap your niche and generate scripts.

8/ Grab "50 Viral Short-Form Video Prompts" for $12.

PDF + Markdown. Instant download.

→ aitoolkit-blog.vercel.app/products

(Full disclosure: includes affiliate links.)

---

## Short-form video scripts

### Script A (15 sec)

0-3: “I used to spend 30 minutes on a 15-second hook.”
3-7: “Then I built fill-in-the-blank prompts for every framework.”
7-12: “Mistake, result, hot take, comparison, story — 50 prompts.”
12-15: “Link in bio. $12.”

### Script B (30 sec)

0-3: “Want Reels that actually get watched?”
3-8: “You need a hook framework, not talent.”
8-18: “I made 50 prompts for the 10 frameworks that stop the scroll.”
18-25: “Copy, paste your niche, shoot.”
25-30: “Link in bio. $12.”

---

## Email blast

Subject: 50 prompts that stop the scroll

Preheader: For Reels, TikTok, Shorts — $12

Body:

Hey [first name],

Short-form video lives and dies in the first 3 seconds.

I built a prompt pack with 50 hooks across 10 proven frameworks so you never start from a blank screen again.

Each prompt is fill-in-the-blank. Run it in ChatGPT, Claude, or your favorite AI writer, then pair it with AI voice or video tools.

50 Viral Short-Form Video Prompts — $12, instant download.

Grab it: [link]

[Name]

P.S. — Best paired with Synthesia or Speechify. Links inside.
