# 50 Viral Short-Form Video Prompts for AI Voice + AI Video

A ready-to-use prompt library for creators who want to ship Reels, TikToks, and YouTube Shorts faster — without running out of hooks.

## Included (∼6,500 words)

10 prompt frameworks × 5 variations each = **50 prompts**, organized by objective:

1. **The Mistake Hook** — lead with what NOT to do
2. **The Result Hook** — show the outcome in the first 3 seconds
3. **The Comparison Hook** — this vs. that
4. **The Story Hook** — "I used to... until I..."
5. **The Hot Take Hook** — contrarian opinion that stops the scroll
6. **The Question Hook** — make the viewer answer in their head
7. **The Steal-This Hook** — "Copy this exact [thing]"
8. **The Process Hook** — show the transformation
9. **The Myth Hook** — "Everyone thinks X. The truth is Y."
10. **The CTA Hook** — direct response format

## How to use

1. Pick a framework that matches your goal (authority, traffic, leads, sales).
2. Swap the bracketed placeholders for your niche/topic.
3. Run the prompt in ChatGPT, Claude, Copy.ai, or Writesonic.
4. Pair the output with:
   - **Synthesia** (https://synthesia.io/?via=aitoolkit) for AI avatars
   - **Speechify** (https://speechify.com/?via=aitoolkit) for AI voiceovers

## License

Personal use only. Do not redistribute.

© 2026 AI ToolKit.
