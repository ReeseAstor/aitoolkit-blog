Stop guessing hooks. Copy-paste 50 fill-in-the-blank prompts for Reels, TikTok, and YouTube Shorts.

If you’ve ever opened your phone to make a Short and drawn a blank on line one, this is for you.

**50 Viral Short-Form Video Prompts** is a ready-to-run prompt library built for creators who use AI voice and AI video tools. Inside you’ll find 10 proven hook frameworks — each with 5 variations — so you never start from zero.

## What’s inside

- **10 frameworks** (Mistake, Result, Comparison, Story, Hot Take, Question, Steal-This, Process, Myth, CTA)
- **50 fill-in-the-blank prompts** (∼6,500 words)
- Each prompt optimized for 15–60 second videos
- BONUS: AI voice + AI video tool stack guide

## Perfect for

- Coaches and course creators building authority
- Ecommerce brands driving traffic
- Service providers who want leads from short video
- Anyone trying to post daily without burning out

## Format

Instant PDF + Markdown download. Personal use only.

## Recommended stack

Pair these prompts with:
- **Synthesia** for AI avatars and video generation
- **Speechify** for natural AI voiceovers

Both linked inside the file.

—

*Affiliate disclosure: includes links to Synthesia and Speechify. We may earn a commission at no extra cost if you sign up.*
