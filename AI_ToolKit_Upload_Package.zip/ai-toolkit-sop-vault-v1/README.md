# AI ToolKit SOP Vault — Vol. 1: Marketing Operations

A drop-in-ready collection of 15 standard operating procedures for small-business owners, solopreneurs, and content creators who want to hand off repetitive marketing work to AI.

Each SOP is structured as:
- **Purpose** — when to use it
- **Inputs** — what you need before starting
- **AI tool stack** — recommended tools with affiliate-free honest notes
- **Step-by-step workflow** — the exact prompt sequence
- **Output format** — what success looks like
- **QA checklist** — how to review before publishing/sending

## What’s inside

1. **Weekly LinkedIn Thought-Leadership Post SOP** — turn one insight into 5 posts
2. **Newsletter-from-Article SOP** — repurpose any blog post into an email
3. **SEO Blog Brief SOP** — research → outline → article brief in 20 min
4. **Product Description Bulk Rewrite SOP** — handle 100+ SKUs with one workflow
5. **Cold Outreach Sequence SOP** — generate 40 personalized first lines + 3 follow-ups
6. **Testimonial Request SOP** — collect social proof on autopilot
7. **Customer Support Response SOP** — triage, personalize, escalate
8. **Ad Creative Brief SOP** — brief + copy + creative direction for paid ads
9. **YouTube Script from Blog SOP** — convert an article into a 6-minute script
10. **Podcast Show Notes SOP** — transcript → summary → hooks → timestamps
11. **Twitter/X Thread from Newsletter SOP** — atomize one email into a thread
12. **Lead Magnet Landing Page SOP** — headline → bullets → CTA in 30 min
13. **Case Study from Win SOP** — interview → structure → publish
14. **Pricing Page Rewrite SOP** — convert features into outcome language
15. **Quarterly Content Audit SOP** — identify winners, prune losers, plan next quarter

## How to use this vault

1. Pick the SOP for the workflow you want to automate.
2. Copy the prompt blocks into ChatGPT, Claude, or your preferred AI writing tool.
3. Replace the bracketed placeholders with your actual copy/data.
4. Run the AI, then apply the QA checklist before shipping.

## Recommended tool stack

For the best results with these SOPs, we recommend:

- **Copy.ai** — best all-around AI copywriter for marketing workflows. Try it here: https://copy.ai/?via=aitoolkit
- **Writesonic** — strongest for long-form SEO content and bulk product copy. Try it here: https://writesonic.com/?via=aitoolkit

Both links are affiliate links; we may earn a commission if you sign up (FTC disclosure: https://aitoolkit-blog.vercel.app/disclosure.html).

---

© 2026 AI ToolKit. For AI ToolKit subscribers and readers only. Do not redistribute.
