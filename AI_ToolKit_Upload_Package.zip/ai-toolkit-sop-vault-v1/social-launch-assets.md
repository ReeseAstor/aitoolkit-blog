# Social Launch Assets — AI ToolKit SOP Vault Vol. 1

## Carousels

### Carousel 1: The "15 SOPs" Hook (Instagram / LinkedIn / X)

**Slide 1:**
Headline: 15 marketing workflows you can hand off to AI today
Sub: SOP Vault Vol. 1 — link in bio / comments

**Slide 2:**
Problem: Most founders waste hours every week rewriting the same content, emails, and briefs.

**Slide 3:**
Solution: Give AI the exact process. Get consistent, usable output every time.

**Slide 4:**
What you get:
• LinkedIn posts
• SEO blog briefs
• Cold email sequences
• YouTube scripts
• Customer support replies
• Pricing page rewrites
• + 9 more

**Slide 5:**
Every SOP includes:
Purpose → Inputs → Prompts → Outputs → QA checklist

**Slide 6:**
CTA: Grab the vault for $19. Link → aitoolkit-blog.vercel.app/products

---

### Carousel 2: Before/After (TikTok / Reels / Shorts frames)

**Frame 1:** BEFORE — “AI, write me a LinkedIn post” (vague, generic output)
**Frame 2:** AFTER — “AI, run SOP 01 with this insight and this audience” (specific, usable output)
**Frame 3:** The difference is not the tool. It’s the system.
**Frame 4:** 15 systems. $19. Link → aitoolkit-blog.vercel.app/products

---

## Twitter/X thread

1/ I’ve built 100+ AI-assisted workflows this year.

The biggest mistake people make:

They ask AI to "write a post" and expect magic.

The people winning use SOPs — precise prompt sequences that produce usable work every time.

Here are 15 of mine 👇

2/ LinkedIn Thought Leadership SOP

Input: one insight from your week.
Output: 5 post options with hooks.
Result: never stare at a blank feed again.

3/ Newsletter-from-Article SOP

Input: any blog article.
Output: 5-section email in 15 min.
Result: blog traffic + engaged list on autopilot.

4/ SEO Blog Brief SOP

Input: keyword + 2 competitors.
Output: full article brief with H2s, angles, affiliate placements.
Result: content that ranks, not just content that gets published.

5/ Cold Outreach Sequence SOP

Input: prospect list + trigger.
Output: personalized first lines + 3 follow-ups.
Result: replies instead of radio silence.

6/ Customer Support Response SOP

Input: ticket message.
Output: classified + replied in < 2 min.
Result: fast support without sounding like a bot.

7/ Quarterly Content Audit SOP

Input: analytics + email data.
Output: winners / sleepers / zombies / stars plan.
Result: stop guessing what to publish next.

8/ + 8 more SOPs inside the vault:

• Bulk product descriptions
• Testimonial requests
• Ad creative briefs
• YouTube scripts
• Podcast show notes
• Twitter threads from newsletters
• Lead magnet landing pages
• Case studies from wins
• Pricing page rewrites

9/ Each SOP includes purpose, inputs, AI tool stack, exact prompts, output format, and QA checklist.

No fluff. Just systems you can run today.

Grab AI ToolKit SOP Vault Vol. 1 → aitoolkit-blog.vercel.app/products

(Full disclosure: includes affiliate links to Copy.ai and Writesonic.)

---

## Short-form video scripts

### TikTok / Reels / Shorts — Script A (Hook + Problem + Solution)

**0-3 sec:** “I wasted 6 months asking AI to ‘write me a post.’ It was garbage.”
**3-8 sec:** “Then I started using SOPs — exact prompt systems.”
**8-15 sec:** “Now I can turn one insight into 5 LinkedIn posts, one article into a newsletter, one blog into a YouTube script.”
**15-22 sec:** “I turned my best 15 marketing SOPs into the AI ToolKit SOP Vault.”
**22-30 sec:** “$19. PDF + Markdown. Link in bio.”

### TikTok / Reels / Shorts — Script B (Specific SOP Demo)

**0-3 sec:** “Cold emails getting ignored? Try this SOP.”
**3-10 sec:** “Instead of ‘I hope you’re well,’ use a trigger from their LinkedIn or company news.”
**10-18 sec:** “AI writes a personalized first line + 3 follow-ups, all under 120 words.”
**18-25 sec:** “This SOP plus 14 others are in the AI ToolKit SOP Vault.”
**25-30 sec:** “Link in bio. $19.”

---

## Email blast (single-send)

**Subject:** The SOPs I use to run marketing with AI

**Preheader:** 15 copy-paste systems — $19

**Body:**

Hey [first name],

I built 15 standard operating procedures for marketing workflows I used to do manually.

Each one is a complete system:
- what to feed the AI
- which tool to use
- the exact prompt
- what the output should look like
- how to quality-check it

The result? I can hand off LinkedIn posts, email newsletters, SEO briefs, cold outreach, customer support replies, YouTube scripts, and more to AI — and get usable work back.

I packaged them into the AI ToolKit SOP Vault Vol. 1.

It’s $19. You get PDF + editable Markdown.

Grab it here: [link]

Talk soon,
[Name]

P.S. — If you want the best results, run these SOPs in Copy.ai or Writesonic. Both are linked inside the vault.
