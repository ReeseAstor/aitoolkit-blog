# Social Launch Assets — Midjourney + DALL-E Prompt Lab

## Twitter/X Thread

1/ Most people use Midjourney like a slot machine.

Type something. Hope. Repeat.

Here's how marketers actually get usable images →

2/ The formula:

[Subject] + [Composition] + [Style] + [Lighting] + [Color] + [Parameters]

That's it. Every good prompt follows it.

3/ Example:

"A ceramic mug on marble, centered product shot, photorealistic, soft morning light, warm neutral tones --ar 1:1 --v 6 --style raw"

Usable. Repeatable. On-brand.

4/ The secret weapon nobody talks about: negative prompts.

--no extra fingers, watermark, text, clutter

Kills 80% of the garbage.

5/ I packaged 100 market-ready prompts across 10 categories:

Product mockups, ads, thumbnails, social, heroes, logos, flat-lays, and more.

6/ Plus the formula, parameter cheat sheet, and negative prompt bank.

$13. Instant download.

→ aitoolkit-blog.vercel.app/products

---

## Short-form video scripts

### Script A (30 sec)
0-3: “Your AI images look like AI images. Here’s the fix.”
3-8: “Marketing images follow a formula, not luck.”
8-18: “Subject, composition, style, lighting, color, parameters.”
18-25: “I made 100 prompts for mockups, ads, thumbnails, and social.”
25-30: “Link in bio. $13.”

### Script B (15 sec)
0-3: “100 Midjourney + DALL-E prompts.”
3-8: “For marketing images that actually work.”
8-13: “Mockups, ads, thumbnails, social.”
13-15: “$13. Link in bio.”

---

## Email blast

Subject: 100 AI image prompts that don't look like AI

Preheader: Mockups, ads, thumbnails + the formula — $13

Body:

Hey [first name],

If your Midjourney and DALL-E images come out unusable, it's not the tool — it's the prompt.

I built 100 market-ready prompts across 10 categories: product mockups, social backgrounds, blog heroes, ad creative, thumbnails, and more.

Plus the prompt formula, a parameter cheat sheet, and a negative prompt bank to kill artifacts.

Get the Prompt Lab — $13.

Grab it: [link]

[Name]
