# Social Launch Assets — AI ToolKit Ultimate Bundle

## Twitter/X Thread

1/ I built 9 AI products this year.

SOPs. Prompts. Templates. Swipes. Systems.

Now you can get all of them in one library →

2/ Writing & ops:
- AI ToolKit SOP Vault
- The AI SEO Content System
- Cold Email AI Swipe File
- The AI Small Business Stack Playbook

3/ Content & creative:
- 50 Viral Short-Form Video Prompts
- AI Social Media Content Machine
- YouTube Creator AI Toolkit
- Midjourney + DALL-E Prompt Lab
- AI Ecommerce Description Templates

4/ Bought separately: $146.

The Ultimate Bundle: $97. (34% off)

5/ And it includes free updates for life — plus first access and a discount on every future product.

→ aitoolkit-blog.vercel.app/products

---

## Short-form video scripts

### Script A (30 sec)
0-3: “Everything I’ve built for running a business with AI.”
3-10: “SOPs, SEO, ecommerce, cold email, social, video, image prompts, and strategy.”
10-18: “9 products. 1 library.”
18-25: “$146 of products for $97. Free updates for life.”
25-30: “Link in bio.”

### Script B (15 sec)
0-3: “All 9 AI ToolKit products.”
3-8: “One bundle. 34% off.”
8-13: “$97. Free updates for life.”
13-15: “Link in bio.”

---

## Email blast

Subject: Everything I’ve built, one bundle

Preheader: All 9 AI products — $97 (save $49)

Body:

Hey [first name],

This is the whole library.

All 9 AI ToolKit products — SOPs, SEO, ecommerce templates, cold email swipes, a social content machine, video prompts, a YouTube toolkit, an image prompt lab, and the small business stack playbook.

$146 of products for $97. Free updates for life, plus first access and a discount on everything I release next.

Get the AI ToolKit Ultimate Bundle: [link]

[Name]
