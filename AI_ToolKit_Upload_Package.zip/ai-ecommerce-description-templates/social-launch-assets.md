# Social Launch Assets — AI-Powered Ecommerce Product Description Templates

## Short-form video scripts

### Script A (30 sec)
0-3: “You have 100 products. You need descriptions. Fast.”
3-8: “I made 40 templates across 8 proven ecommerce frameworks.”
8-18: “Story, Spec, Benefit, Lifestyle, Comparison, Urgency, Social Proof, Mini-Review.”
18-25: “Just swap the brackets, run through AI, upload.”
25-30: “Link in bio. $14.”

### Script B (15 sec)
0-3: “Etsy descriptions are killing your sales?”
3-8: “Use a framework that sells.”
8-13: “40 templates. $14. Link in bio.”

---

## Email blast

Subject: 40 ecommerce description templates

Preheader: For Etsy, Shopify, Amazon — $14

Body:

Hey [first name],

Product descriptions are the silent salesperson of every listing.

I put together 40 fill-in-the-blank templates across 8 proven frameworks — Story, Spec, Benefit, Lifestyle, Comparison, Urgency, Social Proof, and Mini-Review.

Plus a bulk-rewrite workflow so you can power through 100+ SKUs with Copy.ai.

Grab the pack: [link]

[Name]
