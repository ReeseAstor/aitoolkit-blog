# Social Launch Assets — AI Content Creator Vault

## Twitter/X Thread

1/ The complete AI content stack — in one download.

Short-form. Daily social. Long-form YouTube.

Here's what's in the vault →

2/ 50 Viral Short-Form Video Prompts.

Hook-first prompts for Reels, TikTok, and Shorts. Stop guessing at openers.

3/ AI Social Media Content Machine.

A 30-day calendar with prompts, hooks, and hashtag banks. Never stare at a blank screen again.

4/ YouTube Creator AI Toolkit.

5 script frameworks, 30 hooks, thumbnail prompts, 25 title patterns, and an SEO description template.

5/ Bought separately: $45.

The vault: $37. Free updates for life.

→ aitoolkit-blog.vercel.app/products

---

## Short-form video scripts

### Script A (30 sec)
0-3: “Every AI content template you need — in one vault.”
3-8: “Short-form video prompts.”
8-14: “A 30-day social calendar.”
14-20: “And the full YouTube creator toolkit.”
20-26: “$45 of products for $37. Free updates for life.”
26-30: “Link in bio.”

### Script B (15 sec)
0-3: “The AI content creator vault.”
3-8: “Video prompts + social calendar + YouTube toolkit.”
8-13: “$37. Save 18%.”
13-15: “Link in bio.”

---

## Email blast

Subject: The whole AI content stack, one download

Preheader: Video + social + YouTube — $37 (save 18%)

Body:

Hey [first name],

If you make content, you need three things: short-form hooks, a daily posting system, and a YouTube workflow.

I bundled all three:

- 50 Viral Short-Form Video Prompts
- AI Social Media Content Machine (30-day calendar)
- YouTube Creator AI Toolkit

$45 of products for $37 — with free updates for life.

Get the AI Content Creator Vault: [link]

[Name]
